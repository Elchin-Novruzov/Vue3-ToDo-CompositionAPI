<template>
  <h1 :class="$style['page-title']">ToDo List</h1>
  <p :class="$style.subtitle">
    A todo app powered by
    <a href="https://v3.vuejs.org/">Vue 3</a>
    <span>, </span>
    <a href="https://vitejs.dev/">Vite</a>
    <span>, </span>
      <a href="https://classic.yarnpkg.com/en/">Yarn</a>
    <span> & </span>
    <a href="https://vuejs.org/guide/extras/composition-api-faq.html">Composition API </a>
  </p>
</template>

<style module>
.page-title {
  font-family: 'DM Serif Display', serif;
  font-size: 44px;
  letter-spacing: 1.84px;
  color: #2d2d2d;
  margin-top: 104px;
  margin-bottom: 0;
}

.subtitle {
  font-size: 1rem;
  font-weight: bold;
  color: #6b6b6b;
  margin-top: 0;
  margin-bottom: 30px;
  letter-spacing: 0.67px;
}
</style>
